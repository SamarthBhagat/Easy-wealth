EASY WEALTH WEBSITE + CUSTOMER DATABASE / CRM
==============================================

Database recommendation: Supabase (PostgreSQL database + Authentication).
This is a starter implementation; it does not create a cloud database for you automatically.

FILES
- index.html, style.css, script.js: public website
- config.js: Supabase connection placeholders
- schema.sql: database tables and row-level security rules
- admin.html, admin.css, admin.js: login-protected CRM dashboard
- easy-wealth-logo.png and services-banner.png: your supplied assets

SETUP
1. Create a project at https://supabase.com/
2. In Project Settings > API, copy Project URL and anon/public key.
3. Replace placeholders in config.js with those values.
   NEVER put a service_role key or database password in browser JavaScript.
4. In Supabase > SQL Editor, run the entire schema.sql file.
5. In Supabase Authentication settings, disable public sign-ups.
6. Create/invite your own admin account manually in Authentication > Users.
7. Use VS Code Live Server to run this folder, or deploy it to a static HTTPS host.
8. Open index.html and submit a test enquiry; it should be saved in enquiries.
9. Open admin.html and sign in with the admin user created in step 6.
10. Test adding customers, follow-ups, investment/insurance CRM records, status updates and CSV exports.

DATA
customers: contact details
enquiries: website leads and their status
follow_ups: call history / next contact date
investment_records: basic CRM tracking for investment discussions
insurance_records: basic CRM tracking for insurance discussions

CSV / EXCEL
Reports download as CSV files which Microsoft Excel can open. This is not a native .xlsx export.

SECURITY
- Public visitors may submit website enquiries but cannot read CRM data.
- Authenticated users have staff/admin access to all CRM tables; keep sign-ups disabled and only create trusted accounts.
- Add CAPTCHA/rate limiting or a server-side Edge Function before broad public launch to reduce spam.
- Use HTTPS, strong passwords and MFA where available.
- Do not store Aadhaar/PAN images, OTPs, bank logins, card details, passwords, or full policy documents in this basic CRM.
- Exported files contain personal data; protect and delete them when no longer needed.
- Check applicable privacy and financial-services regulations before going live.
- This is a lead/record management CRM, not a system for executing financial transactions.
