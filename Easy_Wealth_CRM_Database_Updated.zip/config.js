// Supabase browser config. Use the anon/public key only; NEVER use service_role here.
window.EASY_WEALTH_CONFIG = {
  SUPABASE_URL: "https://YOUR-PROJECT.supabase.co",
  SUPABASE_ANON_KEY: "YOUR_SUPABASE_ANON_KEY"
};