-- Easy Wealth CRM schema. Run in Supabase Dashboard > SQL Editor.
-- Create admin users manually in Supabase Auth and disable public sign-ups.
create extension if not exists pgcrypto;

create table if not exists public.customers (
 id uuid primary key default gen_random_uuid(), full_name text not null, phone text not null,
 email text, city text, preferred_contact text default 'Phone', notes text,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.enquiries (
 id uuid primary key default gen_random_uuid(), customer_name text not null, phone text not null,
 email text, interest text not null default 'General enquiry', message text,
 source text not null default 'Website',
 status text not null default 'new' check(status in ('new','contacted','follow_up','converted','closed')),
 assigned_to text, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.follow_ups (
 id uuid primary key default gen_random_uuid(), customer_id uuid references public.customers(id) on delete set null,
 enquiry_id uuid references public.enquiries(id) on delete set null, customer_name text not null, phone text,
 follow_up_date date not null default current_date, channel text not null default 'Phone',
 outcome text, next_follow_up date, notes text, created_by uuid references auth.users(id) on delete set null,
 created_at timestamptz not null default now()
);
create table if not exists public.investment_records (
 id uuid primary key default gen_random_uuid(), customer_id uuid references public.customers(id) on delete set null,
 customer_name text not null, product_type text not null default 'Mutual Fund', provider text,
 scheme_or_product text, amount numeric(14,2), frequency text, start_date date,
 status text not null default 'prospect', notes text, created_at timestamptz not null default now()
);
create table if not exists public.insurance_records (
 id uuid primary key default gen_random_uuid(), customer_id uuid references public.customers(id) on delete set null,
 customer_name text not null, insurance_type text not null default 'Life', insurer text,
 policy_reference text, premium_amount numeric(14,2), premium_frequency text, renewal_date date,
 status text not null default 'prospect', notes text, created_at timestamptz not null default now()
);

create index if not exists enquiries_created_idx on public.enquiries(created_at desc);
create index if not exists enquiries_status_idx on public.enquiries(status);
create index if not exists followups_date_idx on public.follow_ups(next_follow_up);

alter table public.customers enable row level security;
alter table public.enquiries enable row level security;
alter table public.follow_ups enable row level security;
alter table public.investment_records enable row level security;
alter table public.insurance_records enable row level security;

drop policy if exists "Public can submit website enquiries" on public.enquiries;
create policy "Public can submit website enquiries" on public.enquiries
 for insert to anon, authenticated with check (status='new' and source='Website');

drop policy if exists "Staff manage enquiries" on public.enquiries;
create policy "Staff manage enquiries" on public.enquiries
 for all to authenticated using (true) with check (true);
drop policy if exists "Staff manage customers" on public.customers;
create policy "Staff manage customers" on public.customers
 for all to authenticated using (true) with check (true);
drop policy if exists "Staff manage followups" on public.follow_ups;
create policy "Staff manage followups" on public.follow_ups
 for all to authenticated using (true) with check (true);
drop policy if exists "Staff manage investments" on public.investment_records;
create policy "Staff manage investments" on public.investment_records
 for all to authenticated using (true) with check (true);
drop policy if exists "Staff manage insurance" on public.insurance_records;
create policy "Staff manage insurance" on public.insurance_records
 for all to authenticated using (true) with check (true);

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at=now(); return new; end; $$;
drop trigger if exists customers_updated_at on public.customers;
create trigger customers_updated_at before update on public.customers
 for each row execute function public.set_updated_at();
drop trigger if exists enquiries_updated_at on public.enquiries;
create trigger enquiries_updated_at before update on public.enquiries
 for each row execute function public.set_updated_at();
